package com.example.trabalhomarcos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabalhomarcosApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrabalhomarcosApplication.class, args);
	}

}
