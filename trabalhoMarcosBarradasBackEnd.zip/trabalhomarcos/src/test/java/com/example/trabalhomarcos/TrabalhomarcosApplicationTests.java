package com.example.trabalhomarcos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabalhomarcosApplicationTests {

	@Test
	void contextLoads() {
	}

}
